package alive;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Alive extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Dashboard dashboard = new Dashboard();
        Scene scene = new Scene(dashboard.createDashboard(), 800, 600, Color.LIGHTGRAY);

        primaryStage.setTitle("Task and Deadline Manager");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }
}
