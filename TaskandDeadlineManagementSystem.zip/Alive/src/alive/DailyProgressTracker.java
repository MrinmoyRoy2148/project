/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alive;


import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class DailyProgressTracker {

    // Map to store the number of completed tasks per day
    private Map<LocalDate, Integer> dailyProgress = new HashMap<>();

    // Method to update progress for the given date
    public void updateProgress(LocalDate date, int completedTasks) {
        dailyProgress.put(date, completedTasks); // Update or add completed tasks for the day
    }

    // Method to get the daily progress for the given date
    public int getDailyProgress(LocalDate date) {
        return dailyProgress.getOrDefault(date, 0); // Return the number of completed tasks for the given date
    }

    // Method to display progress (optional)
    public void displayProgress() {
        for (Map.Entry<LocalDate, Integer> entry : dailyProgress.entrySet()) {
            System.out.println("Date: " + entry.getKey() + ", Completed tasks: " + entry.getValue());
        }
    }
}
