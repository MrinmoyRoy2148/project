package alive;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.geometry.Pos;
import javafx.stage.Stage;

public class QuoteEditorPage {

    private static ListView<String> quoteListView = new ListView<>();
    private static TextField newQuoteField = new TextField();

    public static void display() {
        Stage quoteEditorStage = new Stage();
        quoteEditorStage.setTitle("Quote Editor");

        quoteListView.getItems().clear();
        quoteListView.getItems().addAll(Dashboard.userQuotes);

        newQuoteField.setPromptText("Enter new quote here");

        Button addButton = new Button("Add");
        Button removeButton = new Button("Remove Selected");
        Button saveButton = new Button("Save");
        Button cancelButton = new Button("Cancel");

        String defaultButtonStyle = "-fx-background-color: #4A90E2; -fx-text-fill: white; -fx-background-radius: 8; -fx-padding: 6 12;";
        String hoverStyle = "-fx-background-color: #357ABD;";
        String saveStyle = "-fx-background-color: #28a745; -fx-text-fill: white;";
        String saveHover = "-fx-background-color: #218838;";
        String cancelStyle = "-fx-background-color: #dc3545; -fx-text-fill: white;";
        String cancelHover = "-fx-background-color: #c82333;";

        Button[] defaultButtons = {addButton, removeButton};
        for (Button btn : defaultButtons) {
            btn.setStyle(defaultButtonStyle);
            btn.setOnMouseEntered(e -> btn.setStyle(hoverStyle + defaultButtonStyle));
            btn.setOnMouseExited(e -> btn.setStyle(defaultButtonStyle));
        }

        saveButton.setStyle(saveStyle);
        saveButton.setOnMouseEntered(e -> saveButton.setStyle(saveHover));
        saveButton.setOnMouseExited(e -> saveButton.setStyle(saveStyle));

        cancelButton.setStyle(cancelStyle);
        cancelButton.setOnMouseEntered(e -> cancelButton.setStyle(cancelHover));
        cancelButton.setOnMouseExited(e -> cancelButton.setStyle(cancelStyle));

        addButton.setOnAction(e -> {
            String newQuote = newQuoteField.getText().trim();
            if (!newQuote.isEmpty()) {
                quoteListView.getItems().add(newQuote);
                newQuoteField.clear();
            } else {
                showAlert("Empty Quote", "Please enter a quote to add.");
            }
        });

        removeButton.setOnAction(e -> {
            String selected = quoteListView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                quoteListView.getItems().remove(selected);
            } else {
                showAlert("No Selection", "Please select a quote to remove.");
            }
        });

        saveButton.setOnAction(e -> {
            Dashboard.userQuotes.clear();
            Dashboard.userQuotes.addAll(quoteListView.getItems());
            showAlert("Quotes Saved", "All changes have been saved.");
            quoteEditorStage.close();
        });

        cancelButton.setOnAction(e -> quoteEditorStage.close());

        HBox inputBox = new HBox(10, newQuoteField, addButton);
        inputBox.setAlignment(Pos.CENTER);

        HBox buttonsBox = new HBox(10, removeButton, saveButton, cancelButton);
        buttonsBox.setAlignment(Pos.CENTER);

        VBox layout = new VBox(15, quoteListView, inputBox, buttonsBox);
        layout.setAlignment(Pos.CENTER);
        layout.setPrefSize(500, 400);
        layout.setStyle("-fx-padding: 20; -fx-background-color: #F5F5F5;");

        quoteEditorStage.setScene(new Scene(layout));
        quoteEditorStage.show();
    }

    private static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
