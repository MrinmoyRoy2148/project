package alive;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.geometry.Pos;
import javafx.stage.Stage;

public class TaskEditorPage {

    private static ListView<String> taskListView = new ListView<>();
    private static TextField newTaskField = new TextField();

    public static void display() {
        Stage taskEditorStage = new Stage();
        taskEditorStage.setTitle("Task Editor");

        taskListView.getItems().clear();
        taskListView.getItems().addAll(Dashboard.dashboardTaskListView.getItems());

        newTaskField.setPromptText("Enter new task here");

        Button addButton = new Button("Add");
        Button removeButton = new Button("Remove");
        Button saveButton = new Button("Save");
        Button cancelButton = new Button("Cancel");

        addButton.setStyle("-fx-background-color: #4A4A4A; -fx-text-fill: white;");
        removeButton.setStyle("-fx-background-color: #4A4A4A; -fx-text-fill: white;");
        saveButton.setStyle("-fx-background-color: #28a745; -fx-text-fill: white;");
        cancelButton.setStyle("-fx-background-color: #dc3545; -fx-text-fill: white;");

        addButton.setOnAction(e -> {
            String newTask = newTaskField.getText().trim();
            if (!newTask.isEmpty()) {
                taskListView.getItems().add(newTask);
                newTaskField.clear();
            } else {
                showAlert("Empty Task", "Please enter a task to add.");
            }
        });

        removeButton.setOnAction(e -> {
            String selectedTask = taskListView.getSelectionModel().getSelectedItem();
            if (selectedTask != null) {
                taskListView.getItems().remove(selectedTask);
            } else {
                showAlert("No Selection", "Please select a task to remove.");
            }
        });

        saveButton.setOnAction(e -> {
            Dashboard.dashboardTaskListView.getItems().clear();
            Dashboard.dashboardTaskListView.getItems().addAll(taskListView.getItems());
            showAlert("Tasks Saved", "All changes have been saved.");
            taskEditorStage.close();
        });

        cancelButton.setOnAction(e -> taskEditorStage.close());

        HBox inputBox = new HBox(10, newTaskField, addButton);
        inputBox.setAlignment(Pos.CENTER);

        HBox buttonsBox = new HBox(10, removeButton, saveButton, cancelButton);
        buttonsBox.setAlignment(Pos.CENTER);

        VBox layout = new VBox(15, taskListView, inputBox, buttonsBox);
        layout.setAlignment(Pos.CENTER);
        layout.setPrefSize(400, 400);
        layout.setStyle("-fx-background-color: #F0F0F0; -fx-padding: 20;");

        taskEditorStage.setScene(new Scene(layout));
        taskEditorStage.show();
    }

    private static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
