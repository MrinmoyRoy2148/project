package alive;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.Duration;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;

public class Dashboard {

    public static ListView<String> dashboardTaskListView = new ListView<>();
    public static List<String> userQuotes = new ArrayList<>();
    private static final String DEFAULT_QUOTE = "\"Believe in yourself!\"";
    private static Text quoteText = new Text();
    private static final Random random = new Random();
    public Text deadlineNotification = new Text("No deadlines set yet");
    public Map<LocalDate, List<String>> deadlineMap = new HashMap<>();
    public YearMonth currentYearMonth = YearMonth.now();
    private GridPane calendarGrid = new GridPane();
    private Label monthLabel = new Label();

    private ProgressBar progressBar = new ProgressBar(0);
    private Label progressLabel = new Label("0%");

    private Label tasksSummaryLabel = new Label();
    private Label deadlinesSummaryLabel = new Label();
    private Label encouragementLabel = new Label();

    private int completedTasksCount = 0;

    public BorderPane createDashboard() {
        BorderPane borderPane = new BorderPane();

        // Sidebar with buttons
        VBox sidebar = new VBox(20);
        sidebar.setPadding(new Insets(50, 10, 10, 10));
        sidebar.setStyle("-fx-background-color: #D3D3D3;");

        Button taskEditorButton = new Button("Task Editor");
        Button deadlineEditorButton = new Button("Deadline Editor");
        Button quoteEditorButton = new Button("Quote Editor");
        Button aboutUsButton = new Button("About Us");

        String buttonStyle = "-fx-background-color: #4A4A4A; -fx-text-fill: white; -fx-padding: 6px;";
        double buttonWidth = 120;
        double buttonHeight = 25;

        for (Button btn : new Button[]{taskEditorButton, deadlineEditorButton, quoteEditorButton, aboutUsButton}) {
            btn.setStyle(buttonStyle);
            btn.setMinSize(buttonWidth, buttonHeight);
        }

        sidebar.getChildren().addAll(taskEditorButton, deadlineEditorButton, quoteEditorButton, aboutUsButton);
        borderPane.setLeft(sidebar);

        // Task List with checkbox items
        Text taskListTitle = new Text("Task List");
        taskListTitle.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        taskListTitle.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);

        VBox taskListContainer = new VBox(10);
        taskListContainer.setAlignment(Pos.TOP_CENTER);
        taskListContainer.setPadding(new Insets(10));
        taskListContainer.setStyle("-fx-background-color: #CBE0DC;");
        taskListContainer.getChildren().addAll(taskListTitle, dashboardTaskListView);

        dashboardTaskListView.getItems().clear();
        dashboardTaskListView.setCellFactory(new Callback<>() {
            @Override
            public ListCell<String> call(ListView<String> param) {
                return new ListCell<>() {
                    CheckBox checkBox = new CheckBox();
                    @Override
                    protected void updateItem(String taskName, boolean empty) {
                        super.updateItem(taskName, empty);
                        if (empty || taskName == null) {
                            setGraphic(null);
                        } else {
                            checkBox.setText(taskName);
                            checkBox.setSelected(false);
                            checkBox.setOnAction(e -> {
                                if (checkBox.isSelected()) {
                                    completedTasksCount++;
                                } else {
                                    completedTasksCount = Math.max(0, completedTasksCount - 1);
                                }
                                updateProgressBar();
                                updateSummaryBox();
                            });
                            setGraphic(checkBox);
                        }
                    }
                };
            }
        });

        ScrollPane taskScrollPane = new ScrollPane(taskListContainer);
        taskScrollPane.setFitToWidth(true);

        // Progress bar
        VBox progressContainer = new VBox(5);
        progressContainer.setAlignment(Pos.CENTER);
        progressContainer.setPadding(new Insets(10));
        progressBar.setPrefWidth(300);
        progressBar.setStyle("-fx-accent: #4CAF50;");
        progressLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        progressContainer.getChildren().addAll(progressBar, progressLabel);

        VBox centerContent = new VBox(10, taskScrollPane, progressContainer);
        centerContent.setAlignment(Pos.TOP_CENTER);
        borderPane.setCenter(centerContent);

        // Deadline notification
        deadlineNotification.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        deadlineNotification.setFill(Color.RED);
        HBox notificationBox = new HBox(deadlineNotification);
        notificationBox.setStyle("-fx-background-color: #FFD1D1; -fx-padding: 10px; -fx-border-radius: 5px;");
        notificationBox.setAlignment(Pos.CENTER);

        VBox topContainer = new VBox(10, notificationBox);
        topContainer.setAlignment(Pos.CENTER);
        borderPane.setTop(topContainer);

        // Quote display
        quoteText.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        quoteText.setWrappingWidth(350);
        quoteText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        HBox quoteBox = new HBox(quoteText);
        quoteBox.setStyle("-fx-background-color: #e0e0e0; -fx-padding: 25px; -fx-border-radius: 10px; -fx-background-radius: 10px;");
        quoteBox.setAlignment(Pos.CENTER);
        VBox quoteBoxContainer = new VBox(10, quoteBox);
        quoteBoxContainer.setAlignment(Pos.CENTER);
        borderPane.setBottom(quoteBoxContainer);

        updateQuote();
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(10), event -> updateQuote()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();

        // Button actions
        taskEditorButton.setOnAction(e -> TaskEditorPage.display());
        deadlineEditorButton.setOnAction(e -> DeadlineEditorPage.display(deadlineMap, this));
        quoteEditorButton.setOnAction(e -> QuoteEditorPage.display());
        aboutUsButton.setOnAction(e -> AboutUsPage.display());

        // Calendar on right
        VBox calendarBox = new VBox(10);
        calendarBox.setAlignment(Pos.TOP_CENTER);
        calendarBox.setPadding(new Insets(10));
        calendarBox.setStyle("-fx-background-color: #D3D3D3;");
        monthLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        VBox calendarBorderBox = new VBox(10, monthLabel, calendarGrid);
        calendarBorderBox.setStyle("-fx-background-color: white; -fx-border-color: black; -fx-border-width: 2px; -fx-padding: 10px;");
        calendarBorderBox.setAlignment(Pos.TOP_CENTER);

        // Summary box
        VBox summaryBox = new VBox(5);
        summaryBox.setAlignment(Pos.CENTER);
        tasksSummaryLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 18));
        deadlinesSummaryLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 18));
        encouragementLabel.setFont(Font.font("Arial", FontPosture.ITALIC, 18));
        encouragementLabel.setTextFill(Color.DARKGREEN);
        summaryBox.getChildren().addAll(tasksSummaryLabel, deadlinesSummaryLabel, encouragementLabel);

        VBox rightContent = new VBox(50, calendarBorderBox, summaryBox);
        rightContent.setAlignment(Pos.TOP_CENTER);
        calendarBox.getChildren().add(rightContent);

        renderCalendar(currentYearMonth);
        updateSummaryBox();
        borderPane.setRight(calendarBox);

        return borderPane;
    }

    private void updateQuote() {
        if (userQuotes.isEmpty()) {
            quoteText.setText("Quote for today: " + DEFAULT_QUOTE);
        } else {
            int index = random.nextInt(userQuotes.size());
            quoteText.setText("Quote for today: \"" + userQuotes.get(index) + "\"");
        }
    }

    private void updateSummaryBox() {
        int totalTasks = dashboardTaskListView.getItems().size();
        int completed = completedTasksCount;
        int totalDeadlines = deadlineMap.values().stream().mapToInt(List::size).sum();

        tasksSummaryLabel.setText("Tasks: " + (totalTasks > 0 ? totalTasks : "N/A") + " | Completed: " + (completed > 0 ? completed : "N/A"));
        deadlinesSummaryLabel.setText("Deadlines: " + (totalDeadlines > 0 ? totalDeadlines : "N/A"));

        String encouragementText;
        if (totalTasks == 0) {
            encouragementText = "No tasks to start.";
        } else if (completed == 0) {
            encouragementText = "Let's get started! \uD83D\uDE80";
        } else if (completed == totalTasks) {
            encouragementText = "All done! \u2705";
        } else {
            encouragementText = "You're making progress! \uD83D\uDCAA";
        }

        encouragementLabel.setText(encouragementText);
    }

    public void updateDeadlineNotification() {
        if (deadlineMap.isEmpty()) {
            deadlineNotification.setText("No deadlines set yet");
            return;
        }

        LocalDate today = LocalDate.now();
        LocalDate nearestDate = deadlineMap.keySet().stream()
                .filter(d -> !d.isBefore(today))
                .sorted()
                .findFirst()
                .orElse(null);

        if (nearestDate != null) {
            String taskTitles = String.join(", ", deadlineMap.get(nearestDate));
            String dayOfWeek = nearestDate.getDayOfWeek().toString();
            deadlineNotification.setText("Upcoming Deadline: " + taskTitles + " - " + nearestDate + ", " + capitalize(dayOfWeek.toLowerCase()));
        } else {
            deadlineNotification.setText("No upcoming deadlines");
        }

        renderCalendar(currentYearMonth);
        updateSummaryBox();
    }

    private String capitalize(String input) {
        if (input == null || input.isEmpty()) return input;
        return input.substring(0, 1).toUpperCase() + input.substring(1);
    }

    private void renderCalendar(YearMonth yearMonth) {
        calendarGrid.getChildren().clear();
        calendarGrid.setHgap(5);
        calendarGrid.setVgap(5);
        calendarGrid.setPadding(new Insets(5));

        monthLabel.setText(yearMonth.getMonth().toString() + " " + yearMonth.getYear());

        DayOfWeek[] daysOfWeek = DayOfWeek.values();
        for (int i = 0; i < daysOfWeek.length; i++) {
            Label dayLabel = new Label(daysOfWeek[i].toString().substring(0, 3));
            dayLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
            calendarGrid.add(dayLabel, i, 0);
        }

        LocalDate firstOfMonth = yearMonth.atDay(1);
        int dayOfWeekIndex = firstOfMonth.getDayOfWeek().getValue() % 7; // Sunday=0
        int daysInMonth = yearMonth.lengthOfMonth();
        int row = 1;
        int col = dayOfWeekIndex;

        for (int day = 1; day <= daysInMonth; day++) {
            LocalDate currentDate = yearMonth.atDay(day);
            Button dayButton = new Button(String.valueOf(day));
            dayButton.setMinSize(35, 35);
            dayButton.setMaxSize(35, 35);

            if (deadlineMap.containsKey(currentDate)) {
                dayButton.setStyle("-fx-background-color: #FF6F61; -fx-text-fill: white;");
                dayButton.setOnAction(e -> {
                    List<String> tasks = deadlineMap.get(currentDate);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Deadlines on " + currentDate);
                    alert.setHeaderText("Tasks:");
                    alert.setContentText(String.join("\n", tasks));
                    alert.showAndWait();
                });
            } else {
                dayButton.setStyle("-fx-background-color: #E0F7FA;");
            }

            calendarGrid.add(dayButton, col, row);
            col++;
            if (col > 6) {
                col = 0;
                row++;
            }
        }
    }

    private void updateProgressBar() {
        int completed = completedTasksCount;
        int total = dashboardTaskListView.getItems().size();
        double progress = (total == 0) ? 0 : (double) completed / total;
        progressBar.setProgress(progress);
        int percent = (int) (progress * 100);
        progressLabel.setText("Progress: " + percent + "%");
    }
}
