package alive;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DeadlineEditorPage {

    public static void display(Map<LocalDate, List<String>> deadlineMap, Dashboard dashboard) {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Set Deadline");

        VBox layout = new VBox(15);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        Label instructionLabel = new Label("Enter task and select a deadline date:");
        TextField taskField = new TextField();
        taskField.setPromptText("Enter task name");

        DatePicker datePicker = new DatePicker();
        datePicker.setValue(LocalDate.now());

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);

        Button saveButton = new Button("Save");
        Button cancelButton = new Button("Cancel");
        saveButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        cancelButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");

        saveButton.setOnAction(e -> {
            String task = taskField.getText().trim();
            LocalDate date = datePicker.getValue();

            if (task.isEmpty() || date == null) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please enter a task and select a date.");
                alert.showAndWait();
                return;
            }

            deadlineMap.putIfAbsent(date, new ArrayList<>());
            deadlineMap.get(date).add(task);

            dashboard.updateDeadlineNotification();

            window.close();
        });

        cancelButton.setOnAction(e -> window.close());

        buttonBox.getChildren().addAll(saveButton, cancelButton);
        layout.getChildren().addAll(instructionLabel, taskField, datePicker, buttonBox);

        Scene scene = new Scene(layout, 350, 250);
        window.setScene(scene);
        window.showAndWait();
    }
}
