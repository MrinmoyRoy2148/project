package alive;

import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.geometry.Pos;

public class AboutUsPage {

    public static void display() {
        Stage aboutUsStage = new Stage();
        aboutUsStage.setTitle("About Us");

        VBox layout = new VBox(20);
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: #f0f0f0; -fx-padding: 30;");

        Text title = new Text("About the Project");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-fill: #333333;");

        Text info = new Text(
                "Project completed by Group - B5\n\n" +
                "• Mrinmoy Roy (ID - 48)\n" +
                "• Pushpita Rani Shorna (ID - 53)\n" +
                "• Sharmela Saba (ID - 71)"
        );
        info.setStyle("-fx-font-size: 14px; -fx-fill: #555555;");
        info.setWrappingWidth(250);

        layout.getChildren().addAll(title, info);

        Scene scene = new Scene(layout, 350, 250);
        aboutUsStage.setScene(scene);
        aboutUsStage.show();
    }
}
