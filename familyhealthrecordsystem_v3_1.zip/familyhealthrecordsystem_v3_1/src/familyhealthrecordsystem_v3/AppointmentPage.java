package familyhealthrecordsystem_v3;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.ArrayList;
import java.util.List;

public class AppointmentPage {

    private final List<Appointment> appointmentList = new ArrayList<>();

    public VBox getAppointmentSection() {
        VBox appointmentSection = new VBox(20);
        appointmentSection.setAlignment(Pos.TOP_CENTER);
        appointmentSection.setStyle("-fx-padding: 20; -fx-background-color: #f5f9ff;");
        appointmentSection.setSpacing(15);

        // ScrollPane for scrollable content
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

        // Main content container
        VBox contentBox = new VBox(20);
        contentBox.setAlignment(Pos.TOP_CENTER);
        contentBox.setPadding(new Insets(10));
        contentBox.setMaxWidth(600);

        // Appointment form title
        Label appointmentLabel = new Label("Schedule New Appointment");
        appointmentLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        // Centered form container
        VBox formContainer = new VBox(15);
        formContainer.setStyle("-fx-background-color: white; -fx-padding: 25; -fx-background-radius: 10; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 5, 0, 0, 0);");
        formContainer.setAlignment(Pos.CENTER);
        formContainer.setMaxWidth(400);

        // Doctor Name Field
        VBox doctorBox = new VBox(5);
        doctorBox.setAlignment(Pos.CENTER);
        Label doctorLabel = new Label("Doctor Name");
        doctorLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");
        TextField doctorNameField = new TextField();
        doctorNameField.setPromptText("Enter doctor's name");
        doctorNameField.setStyle("-fx-font-size: 14px; -fx-padding: 8; -fx-background-radius: 5; -fx-border-radius: 5;");
        doctorNameField.setPrefWidth(300);
        doctorBox.getChildren().addAll(doctorLabel, doctorNameField);

        // Date Field
        VBox dateBox = new VBox(5);
        dateBox.setAlignment(Pos.CENTER);
        Label dateLabel = new Label("Appointment Date");
        dateLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");
        DatePicker appointmentDateField = new DatePicker();
        appointmentDateField.setStyle("-fx-font-size: 14px; -fx-padding: 8; -fx-background-radius: 5; -fx-border-radius: 5;");
        appointmentDateField.setPrefWidth(300);
        dateBox.getChildren().addAll(dateLabel, appointmentDateField);

        // Reason Field
        VBox reasonBox = new VBox(5);
        reasonBox.setAlignment(Pos.CENTER);
        Label reasonLabel = new Label("Visit Reason");
        reasonLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");
        TextArea visitReasonField = new TextArea();
        visitReasonField.setPromptText("Describe the reason for visit");
        visitReasonField.setStyle("-fx-font-size: 14px; -fx-padding: 8; -fx-background-radius: 5; -fx-border-radius: 5;");
        visitReasonField.setPrefWidth(300);
        visitReasonField.setPrefRowCount(3);
        reasonBox.getChildren().addAll(reasonLabel, visitReasonField);

        // Save Button
        Button saveButton = new Button("Save Appointment");
        saveButton.setStyle("-fx-font-size: 14px; -fx-padding: 10 25; -fx-background-color: #3498db; -fx-text-fill: white; -fx-background-radius: 5px; -fx-cursor: hand;");
        saveButton.setOnMouseEntered(e -> saveButton.setStyle("-fx-font-size: 14px; -fx-padding: 10 25; -fx-background-color: #2980b9; -fx-text-fill: white; -fx-background-radius: 5px; -fx-cursor: hand;"));
        saveButton.setOnMouseExited(e -> saveButton.setStyle("-fx-font-size: 14px; -fx-padding: 10 25; -fx-background-color: #3498db; -fx-text-fill: white; -fx-background-radius: 5px; -fx-cursor: hand;"));

        // Add all fields to form container
        formContainer.getChildren().addAll(
            doctorBox,
            dateBox,
            reasonBox,
            saveButton
        );

        // Previous visits section
        VBox previousVisitsContainer = new VBox(15);
        previousVisitsContainer.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-background-radius: 10; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 5, 0, 0, 0);");
        previousVisitsContainer.setAlignment(Pos.TOP_CENTER);
        previousVisitsContainer.setMaxWidth(400);

        Label previousVisitsLabel = new Label("Appointment History");
        previousVisitsLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");
        
        ListView<String> previousVisitsListView = new ListView<>();
        previousVisitsListView.setStyle("-fx-font-size: 14px; -fx-background-radius: 5;");
        previousVisitsListView.setPrefHeight(250);
        
        // Save button action
        saveButton.setOnAction(e -> {
            if (doctorNameField.getText().isEmpty() || appointmentDateField.getValue() == null || visitReasonField.getText().isEmpty()) {
                showAlert("Please fill in all fields");
                return;
            }
            
            String doctorName = doctorNameField.getText();
            String appointmentDate = appointmentDateField.getValue().toString();
            String visitReason = visitReasonField.getText();
            
            Appointment appointment = new Appointment(doctorName, appointmentDate, visitReason);
            appointmentList.add(appointment);
            
            updatePreviousVisitsListView(previousVisitsListView);
            
            // Clear fields
            doctorNameField.clear();
            appointmentDateField.setValue(null);
            visitReasonField.clear();
        });

        previousVisitsContainer.getChildren().addAll(previousVisitsLabel, previousVisitsListView);
        
        // Add all components to content box
        contentBox.getChildren().addAll(
                appointmentLabel, 
                formContainer,
                previousVisitsContainer
        );
        
        scrollPane.setContent(contentBox);
        appointmentSection.getChildren().add(scrollPane);

        return appointmentSection;
    }

    private void updatePreviousVisitsListView(ListView<String> listView) {
        listView.getItems().clear();
        for (Appointment appointment : appointmentList) {
            listView.getItems().add(appointment.toString());
        }
    }
    
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Input Validation");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private class Appointment {
        private final String doctorName;
        private final String appointmentDate;
        private final String visitReason;

        public Appointment(String doctorName, String appointmentDate, String visitReason) {
            this.doctorName = doctorName;
            this.appointmentDate = appointmentDate;
            this.visitReason = visitReason;
        }

        @Override
        public String toString() {
            return String.format("Doctor: %-20s | Date: %-12s | Reason: %s", 
                    doctorName, appointmentDate, visitReason);
        }
    }
}