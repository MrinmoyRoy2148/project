package familyhealthrecordsystem_v3;

import javafx.animation.*;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LoginPage {

    private final Stage primaryStage;

    private String signUpUsername = "";
    private String signUpPassword = "";
    private String securityAnswer = "";

    private boolean isAdmin = false;

    public LoginPage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    public Scene getLoginPage() {
        VBox loginVBox = new VBox(15);
        loginVBox.setAlignment(Pos.CENTER);
        loginVBox.setStyle("-fx-background-color: #ffffff; -fx-padding: 30;");
        loginVBox.setPrefWidth(400);

        ImageView logoView = new ImageView();
        try {
            logoView.setImage(new Image("file:/F:/BAUST_2_1/CSE%202100_Software%20Development%20Project%20I/Final_project_image/images%20(1).png"));
        } catch (Exception e) {
            System.out.println("Error loading logo: " + e.getMessage());
        }
        logoView.setFitHeight(100);
        logoView.setPreserveRatio(true);

        Label loginLabel = new Label("Log in to your account");
        loginLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: black; -fx-font-weight: bold;");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameField.setStyle("-fx-font-size: 14px; -fx-padding: 10; -fx-border-radius: 10px; -fx-background-radius: 10px;");
        usernameField.setPrefWidth(350);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.setStyle("-fx-font-size: 14px; -fx-padding: 10; -fx-border-radius: 10px; -fx-background-radius: 10px;");
        passwordField.setPrefWidth(350);

        Hyperlink forgotPasswordLink = new Hyperlink("Forgot Password?");
        forgotPasswordLink.setStyle("-fx-text-fill: #1e90ff; -fx-font-size: 13px;");
        forgotPasswordLink.setOnAction(e -> {
            ForgotPasswordPage forgotPasswordPage = new ForgotPasswordPage(primaryStage, this);
            Scene forgotScene = forgotPasswordPage.getForgotPasswordScene();
            primaryStage.setScene(forgotScene);
        });

        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 14px;");

        Button loginButton = new Button("Login");
        loginButton.setStyle("-fx-font-size: 14px; -fx-padding: 8 20; -fx-background-color: #1e90ff; -fx-text-fill: white; -fx-border-radius: 5px;");

        Button signUpButton = new Button("Sign Up");
        signUpButton.setStyle("-fx-font-size: 14px; -fx-padding: 8 20; -fx-background-color: transparent; -fx-border-color: #1e90ff; -fx-text-fill: #1e90ff;");

        HBox footer = new HBox(10);
        footer.setAlignment(Pos.CENTER);
        Hyperlink privacyPolicyLink = new Hyperlink("Privacy Policy");
        privacyPolicyLink.setStyle("-fx-text-fill: #1e90ff;");
        Hyperlink termsOfUseLink = new Hyperlink("Terms of Use");
        termsOfUseLink.setStyle("-fx-text-fill: #1e90ff;");
        footer.getChildren().addAll(privacyPolicyLink, termsOfUseLink);

        loginVBox.getChildren().addAll(
                logoView,
                loginLabel,
                usernameField,
                passwordField,
                forgotPasswordLink,
                errorLabel,
                loginButton,
                signUpButton,
                footer
        );

        loginButton.setOnAction(e -> {
            String enteredUsername = usernameField.getText();
            String enteredPassword = passwordField.getText();

            if (!enteredUsername.isEmpty() && !enteredPassword.isEmpty() &&
                enteredUsername.equals(signUpUsername) && enteredPassword.equals(signUpPassword)) {
                isAdmin = enteredUsername.equals("admin");
                DashboardPage dashboardPage = new DashboardPage();
                Scene dashboardScene = dashboardPage.getDashboardPage(primaryStage);
                primaryStage.setScene(dashboardScene);
            } else if (enteredUsername.isEmpty() || enteredPassword.isEmpty()) {
                errorLabel.setText("Please enter both username and password.");
            } else {
                errorLabel.setText("Invalid Username or Password. Please try again.");
            }
        });

        signUpButton.setOnAction(e -> {
            SignUpPage signUpPage = new SignUpPage(primaryStage, this);
            Scene signUpScene = signUpPage.getSignUpPage();
            primaryStage.setScene(signUpScene);
        });

        VBox welcomeBox = new VBox(10);
        welcomeBox.setAlignment(Pos.CENTER_LEFT);
        welcomeBox.setPrefWidth(400);
        welcomeBox.setMinWidth(400);
        welcomeBox.setStyle("-fx-background-color: linear-gradient(to bottom right,#00D4FF, #090979, #020024); -fx-padding: 50;");

        Label welcomeTitle = new Label("");
        welcomeTitle.setStyle("-fx-font-size: 32px; -fx-text-fill: white; -fx-font-weight: bold;");
        welcomeTitle.setWrapText(true);
        welcomeTitle.setMaxWidth(300);
        welcomeTitle.setAlignment(Pos.CENTER_LEFT);
        VBox.setVgrow(welcomeTitle, Priority.ALWAYS);
        welcomeBox.getChildren().addAll(welcomeTitle);

        String fullText = "Health Record Management System";
        Timeline typewriter = new Timeline();
        final StringBuilder displayed = new StringBuilder();

        for (int i = 0; i < fullText.length(); i++) {
            final int index = i;
            KeyFrame keyFrame = new KeyFrame(Duration.millis(80 * i), e -> {
                displayed.append(fullText.charAt(index));
                welcomeTitle.setText(displayed.toString());
            });
            typewriter.getKeyFrames().add(keyFrame);
        }

        welcomeTitle.setOpacity(0);
        welcomeTitle.setTranslateY(20);

        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1), welcomeTitle);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);

        TranslateTransition slideUp = new TranslateTransition(Duration.seconds(1), welcomeTitle);
        slideUp.setFromY(20);
        slideUp.setToY(0);

        ParallelTransition parallelIntro = new ParallelTransition(fadeIn, slideUp);
        parallelIntro.setDelay(Duration.millis(300));
        parallelIntro.play();
        typewriter.play();

        HBox root = new HBox();
        root.getChildren().addAll(welcomeBox, loginVBox);

        root.prefWidthProperty().bind(primaryStage.widthProperty());
        root.prefHeightProperty().bind(primaryStage.heightProperty());

        FadeTransition rootFade = new FadeTransition(Duration.seconds(0.8), root);
        rootFade.setFromValue(0);
        rootFade.setToValue(1);
        rootFade.play();

        TranslateTransition rootSlide = new TranslateTransition(Duration.seconds(0.5), root);
        rootSlide.setFromX(-primaryStage.getWidth());
        rootSlide.setToX(0);
        rootSlide.play();

        loginButton.setOnMouseEntered(e -> scaleButton(loginButton, 1.1));
        loginButton.setOnMouseExited(e -> scaleButton(loginButton, 1.0));
        signUpButton.setOnMouseEntered(e -> scaleButton(signUpButton, 1.1));
        signUpButton.setOnMouseExited(e -> scaleButton(signUpButton, 1.0));

        return new Scene(root, 800, 500);
    }

    public void setSignUpCredentials(String username, String password) {
        this.signUpUsername = username;
        this.signUpPassword = password;
    }

    public String getSignUpUsername() {
        return this.signUpUsername;
    }

    public void setSecurityAnswer(String answer) {
        this.securityAnswer = answer.trim().toLowerCase();
    }

    public String getSecurityAnswer() {
        return this.securityAnswer;
    }

    public Scene getLoginPage(Stage primaryStage) {
        return getLoginPage();
    }

    private void scaleButton(Button button, double scale) {
        ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
        st.setToX(scale);
        st.setToY(scale);
        st.play();
    }
}
