package familyhealthrecordsystem_v3;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.ArrayList;
import java.util.List;

public class EmergencyContactPage {

    private final List<EmergencyContact> emergencyContactList = new ArrayList<>();

    // Method to get the ScrollPane containing the Emergency Contact Section
    public ScrollPane getEmergencyContactSection() {
        // Root VBox
        VBox root = new VBox();
        root.setAlignment(Pos.TOP_CENTER);
        root.setPadding(new Insets(20));
        root.setSpacing(20);
        root.setStyle("-fx-background-color: #f4f8fb;");

        // Section container with a card-like style
        VBox emergencyContactSection = new VBox(15);
        emergencyContactSection.setPadding(new Insets(20));
        emergencyContactSection.setAlignment(Pos.TOP_CENTER);
        emergencyContactSection.setStyle("-fx-background-color: white; -fx-border-color: #dcdcdc; -fx-border-radius: 10; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 5, 0, 0, 2);");

        // Title label
        Label title = new Label("Emergency Contact Details");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #007acc;");

        // Input fields
        TextField nameField = new TextField();
        nameField.setPromptText("Contact Name");

        TextField relationshipField = new TextField();
        relationshipField.setPromptText("Relationship");

        TextField phoneField = new TextField();
        phoneField.setPromptText("Phone Number");

        TextArea addressField = new TextArea();
        addressField.setPromptText("Address");
        addressField.setPrefRowCount(3);

        // Style inputs
        for (Control input : new Control[]{nameField, relationshipField, phoneField, addressField}) {
            input.setStyle("-fx-font-size: 14px;");
            VBox.setMargin(input, new Insets(5, 0, 5, 0));
        }

        // Save button
        Button saveButton = new Button("Save Emergency Contact");
        saveButton.setStyle("-fx-font-size: 14px; -fx-padding: 10 20; -fx-background-color: #007acc; -fx-text-fill: white; -fx-background-radius: 5;");
        
        // Previous contacts section
        Label previousContactsLabel = new Label("Previous Emergency Contacts");
        previousContactsLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #007acc;");
        ListView<String> previousContactsListView = new ListView<>();
        previousContactsListView.setPrefHeight(200);

        // Save action
        saveButton.setOnAction(e -> {
            String name = nameField.getText().trim();
            String relationship = relationshipField.getText().trim();
            String phoneNumber = phoneField.getText().trim();
            String address = addressField.getText().trim();

            if (!name.isEmpty() && !relationship.isEmpty() && !phoneNumber.isEmpty() && !address.isEmpty()) {
                EmergencyContact contact = new EmergencyContact(name, relationship, phoneNumber, address);
                emergencyContactList.add(contact);
                updatePreviousContactsListView(previousContactsListView);

                // Clear fields after saving
                nameField.clear();
                relationshipField.clear();
                phoneField.clear();
                addressField.clear();
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please fill in all fields before saving.");
                alert.showAndWait();
            }
        });

        emergencyContactSection.getChildren().addAll(
                title, nameField, relationshipField, phoneField, addressField, saveButton,
                previousContactsLabel, previousContactsListView
        );

        // Add the section to root and wrap it in a ScrollPane
        root.getChildren().add(emergencyContactSection);

        ScrollPane scrollPane = new ScrollPane(root);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent;");

        return scrollPane;
    }

    private void updatePreviousContactsListView(ListView<String> listView) {
        listView.getItems().clear();
        for (EmergencyContact contact : emergencyContactList) {
            listView.getItems().add(contact.toString());
        }
    }

    private static class EmergencyContact {
        private final String name;
        private final String relationship;
        private final String phoneNumber;
        private final String address;

        public EmergencyContact(String name, String relationship, String phoneNumber, String address) {
            this.name = name;
            this.relationship = relationship;
            this.phoneNumber = phoneNumber;
            this.address = address;
        }

        @Override
        public String toString() {
            return "Name: " + name + ", Relationship: " + relationship + ", Phone: " + phoneNumber + ", Address: " + address;
        }
    }
}
