package familyhealthrecordsystem_v3;

import java.util.ArrayList;
import java.util.List;

public class Member {
    private String name;
    private int age;
    private String gender;
    private String birthdate;
    private String bloodGroup;
    private String gmail;
    private String phoneNumber;
    private String photoPath;
    private String address;
    private String prescriptionPath;
    private String labReportPath; // ✅ Added for ED2 support

    // Constructor
    public Member(String name, int age, String gender, String birthdate, String bloodGroup) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.birthdate = birthdate;
        this.bloodGroup = bloodGroup;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPrescriptionPath() {
        return prescriptionPath;
    }

    public void setPrescriptionPath(String prescriptionPath) {
        this.prescriptionPath = prescriptionPath;
    }

    public String getLabReportPath() { // ✅ Fully implemented
        return labReportPath;
    }

    public void setLabReportPath(String labReportPath) { // ✅ Fully implemented
        this.labReportPath = labReportPath;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getGmail() {
        return gmail;
    }

    public void setGmail(String gmail) {
        this.gmail = gmail;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Age: " + age + ", Gender: " + gender + ", Birthdate: " + birthdate + ", Blood Group: " + bloodGroup;
    }

    public String getMemberDetailsWithReports() {
        StringBuilder details = new StringBuilder(toString() + "\n");

        details.append("Gmail: ").append(gmail).append("\n");
        details.append("Phone: ").append(phoneNumber).append("\n");
        details.append("Photo: ").append(photoPath).append("\n");

        return details.toString();
    }

    // You can remove this or leave it unimplemented if not used
    List<String> getLabReports() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
