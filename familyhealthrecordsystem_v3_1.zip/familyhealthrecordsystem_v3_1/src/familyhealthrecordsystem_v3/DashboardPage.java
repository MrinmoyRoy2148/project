package familyhealthrecordsystem_v3;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.util.Duration;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.SequentialTransition;

public class DashboardPage {

    private AppointmentPage appointmentPage = new AppointmentPage();
    private AboutPage aboutPage = new AboutPage();
    private EmergencyContactPage emergencyContactPage = new EmergencyContactPage();

    private List<Member> memberList = new ArrayList<>();
    private List<String> activityLogs = new ArrayList<>();
    private List<String> recentReports = new ArrayList<>();

    private String selectedPhotoPath = "";

    private ListView<String> activityLogsListView = new ListView<>();
    private Stage primaryStage;

    public Scene getDashboardPage(Stage primaryStage) {
        this.primaryStage = primaryStage;
        BorderPane dashboardLayout = new BorderPane();

        VBox leftMenu = new VBox(15);
        leftMenu.setStyle("-fx-background-color: linear-gradient(to right, #24285C, #3D4599, #6772CF);" + "-fx-padding: 20;");
        leftMenu.setPrefWidth(200);
        leftMenu.setAlignment(Pos.TOP_CENTER);

        Label dashboardLabel = new Label("Dashboard");
        dashboardLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: white; -fx-padding: 10;");

        Button addMemberButton = new Button("Add Member");
        Button viewLogsButton = new Button("View Activity Logs");
        Button healthReportButton = new Button("Health Reports");
        Button appointmentButton = new Button("Appointments");
        Button emergencyContactButton = new Button("Emergency Contact");
        Button aboutButton = new Button("About");

        String sidebarButtonStyle = "-fx-font-size: 14px;" +
                "-fx-background-color: linear-gradient(to bottom, #ffffff55, #ffffff22);" +
                "-fx-text-fill: white;" +
                "-fx-padding: 10 20;" +
                "-fx-background-radius: 10;" +
                "-fx-border-radius: 10;" +
                "-fx-border-color: white;" +
                "-fx-border-width: 1;" +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 4, 0.0, 0, 2);" +
                "-fx-cursor: hand;";

        Button[] sidebarButtons = {
                addMemberButton, viewLogsButton, healthReportButton, appointmentButton, emergencyContactButton, aboutButton
        };

        for (Button btn : sidebarButtons) {
            btn.setStyle(sidebarButtonStyle);
            btn.setMaxWidth(Double.MAX_VALUE);
            btn.setMinHeight(40);

            btn.setOnMouseEntered(e -> {
                btn.setStyle("-fx-font-size: 14px;" +
                        "-fx-background-color: linear-gradient(to bottom, #ffffff88, #ffffff33);" +
                        "-fx-text-fill: white;" +
                        "-fx-padding: 10 20;" +
                        "-fx-background-radius: 10;" +
                        "-fx-border-radius: 10;" +
                        "-fx-border-color: white;" +
                        "-fx-border-width: 1;" +
                        "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.6), 6, 0.0, 0, 3);" +
                        "-fx-cursor: hand;");
                ScaleTransition st = new ScaleTransition(Duration.millis(150), btn);
                st.setToX(1.05);
                st.setToY(1.05);
                st.play();
            });

            btn.setOnMouseExited(e -> {
                btn.setStyle(sidebarButtonStyle);
                ScaleTransition st = new ScaleTransition(Duration.millis(150), btn);
                st.setToX(1.0);
                st.setToY(1.0);
                st.play();
            });
        }

        leftMenu.getChildren().addAll(dashboardLabel, addMemberButton, viewLogsButton, healthReportButton, appointmentButton, emergencyContactButton, aboutButton);

        VBox rightContent = new VBox();
        rightContent.setAlignment(Pos.CENTER);
        rightContent.setStyle("-fx-padding: 20;");    //==================================right content
        rightContent.setStyle("-fx-padding: 20; -fx-background-color: linear-gradient(to bottom right,#4E538A, #9398C7);");


        VBox recentReportsSection = createRecentReportsSection();

        dashboardLayout.setLeft(leftMenu);
        dashboardLayout.setCenter(rightContent);

        Scene dashboardScene = new Scene(dashboardLayout, 800, 500, Color.web("#f2f2f2"));

        addMemberButton.setOnAction(e -> {
            VBox memberForm = createMemberForm(primaryStage, rightContent);
            rightContent.getChildren().clear();
            rightContent.getChildren().add(memberForm);
        });

        viewLogsButton.setOnAction(e -> {
            VBox logsView = createActivityLogsView(primaryStage, rightContent);
            rightContent.getChildren().clear();
            rightContent.getChildren().add(logsView);
        });
        

        //================================Health Report========================================//
        //============================================================================================//
        
        
        healthReportButton.setOnAction(e -> {
            VBox logsView = new VBox();
            logsView.setStyle("-fx-padding: 20;");
            
            Label logsLabel = new Label("Health Activity Logs");
            logsLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #1e90ff;");
        
            // Create an HBox to center the search field
            HBox searchBox = new HBox();
            searchBox.setAlignment(Pos.CENTER);  // Center the search field
            searchBox.setSpacing(10);  // Space between the search field and label
        
            // Add the search field
            TextField searchField = new TextField();
            searchField.setPromptText("Search logs...");
            searchField.setMaxWidth(300);
            searchField.setStyle("-fx-font-size: 14px; -fx-padding: 5;");
        
            searchBox.getChildren().add(searchField);
        
            ListView<String> memberLogsListView = new ListView<>();
        
            // Filter activity logs to show only logs that contain member-related information
            for (String log : activityLogs) {
                if (log.contains("Name") || log.contains("Updated member")) {
                    memberLogsListView.getItems().add(log);
                }
            }
        
            // Add listener to filter logs when user types in search field
            searchField.textProperty().addListener((observable, oldValue, newValue) -> {
                List<String> filteredLogs = new ArrayList<>();
                for (String log : activityLogs) {
                    if ((log.contains("Name") || log.contains("Updated member")) &&
                        log.toLowerCase().contains(newValue.toLowerCase())) {
                        filteredLogs.add(log);
                    }
                }
                memberLogsListView.getItems().setAll(filteredLogs);
            });
        
            // Handle member clicks from the activity log list
            memberLogsListView.setOnMouseClicked(e1 -> {
                String selectedLog = memberLogsListView.getSelectionModel().getSelectedItem();
                if (selectedLog != null && selectedLog.contains("Name")) {
                    String memberName = selectedLog.substring("Name: ".length());
                    Member selectedMember = findMemberByName(memberName);
                    if (selectedMember != null) {
                        // Show buttons for ED1(Prescription) and ED2(Lab Report) when a member is selected //ewqafewfewfwegg======================================================
                        showMemberButtons(selectedMember, rightContent);
                    }
                }
            });
        
            logsView.getChildren().addAll(logsLabel, searchBox, memberLogsListView);
            rightContent.getChildren().clear();
            rightContent.getChildren().add(logsView);
        });

        appointmentButton.setOnAction(e -> {
            VBox appointmentSection = appointmentPage.getAppointmentSection();
            rightContent.getChildren().clear();
            rightContent.getChildren().add(appointmentSection);
        });

        emergencyContactButton.setOnAction(e -> {
            ScrollPane emergencyContactSection = emergencyContactPage.getEmergencyContactSection();
            rightContent.getChildren().clear();
            rightContent.getChildren().add(emergencyContactSection);
        });

        aboutButton.setOnAction(e -> {
            VBox aboutSection = aboutPage.getAboutSection();
            rightContent.getChildren().clear();
            rightContent.getChildren().add(aboutSection);
        });

        rightContent.getChildren().add(recentReportsSection);

        return dashboardScene;
    }
    
    private void showMemberButtons(Member member, VBox rightContent) {
        VBox buttonBox = new VBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setStyle("-fx-padding: 20;");

        Button ed1Button = new Button("Prescription");
        Button ed2Button = new Button("Lab Report");

        ed1Button.setOnAction(e -> {
            // Show ED1 content in the same window
            showPrescriptionContent(member, rightContent);
        });

        ed2Button.setOnAction(e -> {
            // Show ED2 content in the same window
            showLabReportContent(member, rightContent);
        });

        buttonBox.getChildren().addAll(ed1Button, ed2Button);
        rightContent.getChildren().clear();
        rightContent.getChildren().add(buttonBox);
    }

    private void showPrescriptionContent(Member member, VBox rightContent) {
        VBox ed1Layout = new VBox(15);
        ed1Layout.setAlignment(Pos.TOP_CENTER);
        ed1Layout.setStyle("-fx-padding: 20;");

        Label ed1Label = new Label("Prescription for " + member.getName());
        ed1Label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #1e90ff;");

        // Search functionality
        HBox searchBox = new HBox(10);
        searchBox.setAlignment(Pos.CENTER);
        TextField searchField = new TextField();
        searchField.setPromptText("Search prescriptions...");
        searchField.setMaxWidth(300);
        Button searchButton = new Button("Search");
        searchBox.getChildren().addAll(searchField, searchButton);

        // Prescription list
        ListView<String> prescriptionListView = new ListView<>();
        if (member.getPrescriptionPath() != null && !member.getPrescriptionPath().isEmpty()) {
            prescriptionListView.getItems().add(member.getPrescriptionPath());
        }

        // View and Delete buttons
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        Button viewButton = new Button("View");
        Button deleteButton = new Button("Delete");
        Button backButton = new Button("Back");
        buttonBox.getChildren().addAll(viewButton, deleteButton, backButton);

        // View button action
        viewButton.setOnAction(e -> {
            String selectedPrescription = prescriptionListView.getSelectionModel().getSelectedItem();
            if (selectedPrescription != null) {
                try {
                    java.awt.Desktop.getDesktop().open(new File(selectedPrescription));
                } catch (Exception ex) {
                    showAlert("Error", "Could not open the file: " + ex.getMessage());
                }
            } else {
                showAlert("No Selection", "Please select a prescription to view.");
            }
        });

        // Delete button action
        deleteButton.setOnAction(e -> {
            String selectedPrescription = prescriptionListView.getSelectionModel().getSelectedItem();
            if (selectedPrescription != null) {
                member.setPrescriptionPath(null);
                prescriptionListView.getItems().clear();
                showAlert("Success", "Prescription deleted successfully.");
            } else {
                showAlert("No Selection", "Please select a prescription to delete.");
            }
        });

        // Search button action
        searchButton.setOnAction(e -> {
            String searchText = searchField.getText().toLowerCase();
            if (member.getPrescriptionPath() != null && 
                member.getPrescriptionPath().toLowerCase().contains(searchText)) {
                prescriptionListView.getItems().clear();
                prescriptionListView.getItems().add(member.getPrescriptionPath());
            } else if (searchText.isEmpty()) {
                if (member.getPrescriptionPath() != null && !member.getPrescriptionPath().isEmpty()) {
                    prescriptionListView.getItems().clear();
                    prescriptionListView.getItems().add(member.getPrescriptionPath());
                }
            } else {
                showAlert("Not Found", "No matching prescription found.");
            }
        });

        // Back button action
        backButton.setOnAction(e -> {
            showMemberButtons(member, rightContent);
        });

        ed1Layout.getChildren().addAll(ed1Label, searchBox, prescriptionListView, buttonBox);

        rightContent.getChildren().clear();
        rightContent.getChildren().add(ed1Layout);
    }

    private void showLabReportContent(Member member, VBox rightContent) {
        VBox ed2Layout = new VBox(15);
        ed2Layout.setAlignment(Pos.TOP_CENTER);
        ed2Layout.setStyle("-fx-padding: 20;");

        Label ed2Label = new Label("Lab Reports for " + member.getName());
        ed2Label.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #1e90ff;");

        // Search functionality
        HBox searchBox = new HBox(10);
        searchBox.setAlignment(Pos.CENTER);
        TextField searchField = new TextField();
        searchField.setPromptText("Search lab reports...");
        searchField.setMaxWidth(300);
        Button searchButton = new Button("Search");
        searchBox.getChildren().addAll(searchField, searchButton);

        // Lab Reports list
        ListView<String> labReportsListView = new ListView<>();
        if (member.getLabReportPath() != null && !member.getLabReportPath().isEmpty()) {
            labReportsListView.getItems().add(member.getLabReportPath());
        }

        // View and Delete buttons
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        Button viewButton = new Button("View");
        Button deleteButton = new Button("Delete");
        Button backButton = new Button("Back");
        buttonBox.getChildren().addAll(viewButton, deleteButton, backButton);

        // View button action
        viewButton.setOnAction(e -> {
            String selectedReport = labReportsListView.getSelectionModel().getSelectedItem();
            if (selectedReport != null) {
                try {
                    java.awt.Desktop.getDesktop().open(new File(selectedReport));
                } catch (Exception ex) {
                    showAlert("Error", "Could not open the file: " + ex.getMessage());
                }
            } else {
                showAlert("No Selection", "Please select a lab report to view.");
            }
        });

        // Delete button action
        deleteButton.setOnAction(e -> {
            String selectedReport = labReportsListView.getSelectionModel().getSelectedItem();
            if (selectedReport != null) {
                member.setLabReportPath(null);
                labReportsListView.getItems().clear();
                showAlert("Success", "Lab report deleted successfully.");
            } else {
                showAlert("No Selection", "Please select a lab report to delete.");
            }
        });

        // Search button action
        searchButton.setOnAction(e -> {
            String searchText = searchField.getText().toLowerCase();
            if (member.getLabReportPath() != null && 
                member.getLabReportPath().toLowerCase().contains(searchText)) {
                labReportsListView.getItems().clear();
                labReportsListView.getItems().add(member.getLabReportPath());
            } else if (searchText.isEmpty()) {
                if (member.getLabReportPath() != null && !member.getLabReportPath().isEmpty()) {
                    labReportsListView.getItems().clear();
                    labReportsListView.getItems().add(member.getLabReportPath());
                }
            } else {
                showAlert("Not Found", "No matching lab report found.");
            }
        });

        // Back button action
        backButton.setOnAction(e -> {
            showMemberButtons(member, rightContent);
        });

        ed2Layout.getChildren().addAll(ed2Label, searchBox, labReportsListView, buttonBox);

        rightContent.getChildren().clear();
        rightContent.getChildren().add(ed2Layout);
    }

    private void showPrescriptionForMember(Member member, VBox rightContent) {
        String prescriptionPath = member.getPrescriptionPath();

        if (prescriptionPath != null && !prescriptionPath.isEmpty()) {
            try {
                Image prescriptionImage = new Image("file:///" + prescriptionPath);
                ImageView prescriptionView = new ImageView(prescriptionImage);
                prescriptionView.setFitHeight(300);
                prescriptionView.setFitWidth(300);

                VBox prescriptionBox = new VBox(10);
                prescriptionBox.setAlignment(Pos.CENTER);
                prescriptionBox.setStyle("-fx-padding: 20;");

                Label prescriptionLabel = new Label("Uploaded Prescription:");
                prescriptionLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #1e90ff;");
                prescriptionBox.getChildren().addAll(prescriptionLabel, prescriptionView);

                rightContent.getChildren().clear();
                rightContent.getChildren().add(prescriptionBox);

            } catch (Exception e) {
                showAlert("Error", "Failed to load the prescription. Please check the file path.");
                e.printStackTrace();
            }
        } else {
            showAlert("No Prescription", "No prescription has been uploaded for this member.");
        }
    }

    
    //==============================================Welcome Page===================================//
    //=============================================================================================//
    
 private VBox createRecentReportsSection() {
    VBox recentReportsSection = new VBox(15);
    recentReportsSection.setAlignment(Pos.CENTER);
    recentReportsSection.setStyle(
       "-fx-background-color: #ffffff;" +
"-fx-padding: 40;" +
"-fx-pref-width: 600;" +
"-fx-pref-height: 500;"

    );

   Label welcomeLabel = new Label("Welcome to your Dashboard");
welcomeLabel.setStyle(
    "-fx-font-size: 28px;" +
    "-fx-font-weight: bold;" +
    "-fx-text-fill: linear-gradient(to right, #005bea, #00c6fb);" +
    "-fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.2), 2, 0.0, 0, 1);" +
    "-fx-padding: 10 0 20 0;"
);


    // === Stats / Metrics ===
    Label statsLabel = new Label("Dashboard Summary");
    statsLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #1e90ff;");

    Label totalMembers = new Label("Total Members: " + memberList.size());
    Label totalReports = new Label("Total Reports Uploaded: " + getTotalReportsCount());
    Label todayAppointments = new Label("Today's Appointments: " + getTodaysAppointmentsCount());

    totalMembers.setStyle("-fx-font-size: 14px; -fx-text-fill: #333;");
    totalReports.setStyle("-fx-font-size: 14px; -fx-text-fill: #333;");
    todayAppointments.setStyle("-fx-font-size: 14px; -fx-text-fill: #333;");

    recentReportsSection.getChildren().addAll(
        welcomeLabel,
        statsLabel, totalMembers, totalReports, todayAppointments
    );

    return recentReportsSection;
}





private int getTotalReportsCount() {
    int count = 0;
    for (Member m : memberList) {
        if ((m.getPrescriptionPath() != null && !m.getPrescriptionPath().isEmpty()) ||
            (m.getLabReportPath() != null && !m.getLabReportPath().isEmpty())) {
            count++;
        }
    }
    return count;
}

private int getTodaysAppointmentsCount() {
    // Placeholder for now – you can connect this to appointmentPage in future
    return 0;
}
               
    
                      //========================================================================================//
    
   //==== PROFESSIONAL UI FOR ADD MEMBER FORM WITH SCROLLPANE ====//
//==== PROFESSIONAL UI FOR ADD MEMBER FORM WITH SCROLLPANE ====//
private VBox createMemberForm(Stage primaryStage, VBox rightContent) {
    VBox formContainer = new VBox();
    formContainer.setStyle("-fx-background-color: #f0f4f8; -fx-padding: 30;");

    VBox memberForm = new VBox(20);
    memberForm.setAlignment(Pos.TOP_CENTER);
    memberForm.setStyle("-fx-padding: 30; -fx-background-color: #ffffff; -fx-border-radius: 10px; -fx-background-radius: 10px; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0.5, 0, 2);");

    Label formLabel = new Label("Add New Member");
    formLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #1e90ff; -fx-padding: 10;");

    ImageView photoView = new ImageView();
    photoView.setFitHeight(120);
    photoView.setFitWidth(120);
    photoView.setStyle("-fx-border-color: #ccc; -fx-border-width: 2px; -fx-border-radius: 8px; -fx-background-color: white;");

    Button uploadPhotoButton = new Button("Upload Photo");
    uploadPhotoButton.setStyle("-fx-background-color: #007bff; -fx-text-fill: white; -fx-padding: 8 16; -fx-font-size: 14px; -fx-cursor: hand; -fx-background-radius: 8px;");
    uploadPhotoButton.setOnAction(e -> {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Member Photo");
        File file = fileChooser.showOpenDialog(primaryStage);
        if (file != null) {
            selectedPhotoPath = file.toURI().toString();
            Image photo = new Image(selectedPhotoPath);
            photoView.setImage(photo);
        }
    });

    GridPane formGrid = new GridPane();
    formGrid.setVgap(15);
    formGrid.setHgap(20);
    formGrid.setAlignment(Pos.CENTER);

    TextField nameField = new TextField(); nameField.setPromptText("Name");
    TextField ageField = new TextField(); ageField.setPromptText("Age");
    TextField genderField = new TextField(); genderField.setPromptText("Gender");
    TextField birthDateField = new TextField(); birthDateField.setPromptText("Birthdate (DD/MM/YYYY)");
    TextField bloodGroupField = new TextField(); bloodGroupField.setPromptText("Blood Group");
    TextField phoneField = new TextField(); phoneField.setPromptText("Phone Number");
    TextField gmailField = new TextField(); gmailField.setPromptText("Email");

    formGrid.add(new Label("Name:"), 0, 0); formGrid.add(nameField, 1, 0);
    formGrid.add(new Label("Age:"), 0, 1); formGrid.add(ageField, 1, 1);
    formGrid.add(new Label("Gender:"), 0, 2); formGrid.add(genderField, 1, 2);
    formGrid.add(new Label("Birthdate:"), 0, 3); formGrid.add(birthDateField, 1, 3);
    formGrid.add(new Label("Blood Group:"), 0, 4); formGrid.add(bloodGroupField, 1, 4);
    formGrid.add(new Label("Phone:"), 0, 5); formGrid.add(phoneField, 1, 5);
    formGrid.add(new Label("Email:"), 0, 6); formGrid.add(gmailField, 1, 6);

    HBox buttonBox = new HBox(20);
    buttonBox.setAlignment(Pos.CENTER);

    Button saveButton = new Button("Save");
    Button backButton = new Button("Back");
    saveButton.setStyle("-fx-background-color: #28a745; -fx-text-fill: white; -fx-padding: 8 20; -fx-font-size: 14px; -fx-background-radius: 10px;");
    backButton.setStyle("-fx-background-color: #dc3545; -fx-text-fill: white; -fx-padding: 8 20; -fx-font-size: 14px; -fx-background-radius: 10px;");

    saveButton.setOnAction(e -> {
        String name = nameField.getText();
        int age;
        try {
            age = Integer.parseInt(ageField.getText());
        } catch (NumberFormatException ex) {
            showAlert("Invalid Input", "Please enter a valid age.");
            return;
        }
        String gender = genderField.getText();
        String birthdate = birthDateField.getText();
        String bloodGroup = bloodGroupField.getText();
        String phone = phoneField.getText();
        String gmail = gmailField.getText();

        Member newMember = new Member(name, age, gender, birthdate, bloodGroup);
        newMember.setPhoneNumber(phone);
        newMember.setGmail(gmail);
        newMember.setPhotoPath(selectedPhotoPath);
        memberList.add(newMember);

        activityLogs.add("Name: " + name);

        showAlert("Success", "Member added successfully!");

        nameField.clear(); ageField.clear(); genderField.clear();
        birthDateField.clear(); bloodGroupField.clear();
        phoneField.clear(); gmailField.clear();
        photoView.setImage(null); selectedPhotoPath = "";
    });

    backButton.setOnAction(e -> {
        rightContent.getChildren().clear();
        rightContent.getChildren().add(createRecentReportsSection());
    });

    buttonBox.getChildren().addAll(saveButton, backButton);
    memberForm.getChildren().addAll(formLabel, photoView, uploadPhotoButton, formGrid, buttonBox);

    ScrollPane scrollPane = new ScrollPane(memberForm);
    scrollPane.setFitToWidth(true);
    scrollPane.setStyle("-fx-background-color: transparent;");

    formContainer.getChildren().add(scrollPane);
    return formContainer;
}


    private VBox createActivityLogsView(Stage primaryStage, VBox rightContent) {
        VBox logsView = new VBox(15);
        logsView.setAlignment(Pos.TOP_CENTER);
        logsView.setStyle("-fx-padding: 20;");

        Label logsLabel = new Label("Activity Logs");
        logsLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #1e90ff;");

        TextField searchField = new TextField();
        searchField.setPromptText("Search logs...");
        searchField.setMaxWidth(300);

        // Initially populate the ListView with all logs
        activityLogsListView.getItems().setAll(activityLogs);

        // Add listener to filter logs when user types in search field
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            List<String> filteredLogs = new ArrayList<>();
            for (String log : activityLogs) {
                if (log.toLowerCase().contains(newValue.toLowerCase())) {
                    filteredLogs.add(log);
                }
            }
            activityLogsListView.getItems().setAll(filteredLogs);
        });

        // Handle member clicks from the activity log list
        activityLogsListView.setOnMouseClicked(e -> {
            String selectedLog = activityLogsListView.getSelectionModel().getSelectedItem();
            if (selectedLog != null && selectedLog.contains("Name")) {
                String memberName = selectedLog.substring("Name: ".length());//=============================================
                Member selectedMember = findMemberByName(memberName);
                if (selectedMember != null) {
                    showMemberProfile(selectedMember, rightContent);
                }
            }
        });

        logsView.getChildren().addAll(logsLabel, searchField, activityLogsListView);
        return logsView;
    }

    private Member findMemberByName(String name) {
        for (Member member : memberList) {
            if (member.getName().equals(name)) {
                return member;
            }
        }
        return null;
    }

    //===================================Profile section============================================//
    //==============================================================================================// 

   private void showMemberProfile(Member member, VBox rightContent) {
    // Create a scrollable layout
    ScrollPane scrollPane = new ScrollPane();
    scrollPane.setFitToWidth(true);
    scrollPane.setFitToHeight(true); // Ensure the scrollPane fits the height of the screen

    // Create VBox for the profile layout
    VBox profileLayout = new VBox(25);
    profileLayout.setAlignment(Pos.TOP_CENTER);
    profileLayout.setStyle(
        "-fx-padding: 40 60 60 60;" +
        "-fx-background-color: #ffffff;" +
        "-fx-border-radius: 20;" +
        "-fx-background-radius: 20;" +
        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 8, 0.3, 0, 2);"
    );

    HBox profileHeader = new HBox(30);
    profileHeader.setAlignment(Pos.CENTER_LEFT);
    profileHeader.setStyle("-fx-padding: 20 10;");

    ImageView photoView = new ImageView();
    if (member.getPhotoPath() != null && !member.getPhotoPath().isEmpty()) {
        Image photo = new Image(member.getPhotoPath());
        photoView.setImage(photo);
    }
    photoView.setFitHeight(140);
    photoView.setFitWidth(140);
    photoView.setStyle("-fx-border-radius: 50%; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 4, 0.4, 0, 2);");

    VBox dataLayout = new VBox(12);
    dataLayout.setStyle("-fx-padding: 10 20;");

    Label nameLabel = new Label("Name: " + member.getName());
    nameLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: normal; -fx-text-fill: #2c3e50; -fx-padding: 3 0;");

    Label ageLabel = new Label("Age: " + member.getAge());
    ageLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #555; -fx-padding: 3 0;");

    Label dobLabel = new Label("Date of Birth: " + member.getBirthdate());
    dobLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #555; -fx-padding: 3 0;");

    Label bloodGroupLabel = new Label("Blood Group: " + member.getBloodGroup());
    bloodGroupLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #555; -fx-padding: 3 0;");

    Label phoneLabel = new Label("Phone: " + member.getPhoneNumber());
    phoneLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #555; -fx-padding: 3 0;");

    Label emailLabel = new Label("Email: " + member.getGmail());
    emailLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #555; -fx-padding: 3 0;");

    dataLayout.getChildren().addAll(nameLabel, ageLabel, dobLabel, bloodGroupLabel, phoneLabel, emailLabel);
    profileHeader.getChildren().addAll(photoView, dataLayout);

    Button prescriptionButton = new Button("Prescription");
    prescriptionButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-padding: 10 25; -fx-background-radius: 8; -fx-font-size: 14px;");
    prescriptionButton.setOnAction(e -> {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.jpg", "*.png"));
        File selectedFile = fileChooser.showOpenDialog(primaryStage);
        if (selectedFile != null) {
            member.setPrescriptionPath(selectedFile.getAbsolutePath());
            showAlert("File Uploaded", "File: " + selectedFile.getName() + " has been uploaded successfully.");
        }
    });

    Button labReportButton = new Button("Lab Report");
    labReportButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-padding: 10 25; -fx-background-radius: 8; -fx-font-size: 14px;");
    labReportButton.setOnAction(e -> {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.jpg", "*.png"));
        File selectedFile = fileChooser.showOpenDialog(primaryStage);
        if (selectedFile != null) {
            member.setLabReportPath(selectedFile.getAbsolutePath());
            showAlert("File Uploaded", "File: " + selectedFile.getName() + " has been uploaded successfully.");
        }
    });

    Button backButton = new Button("Back to Activity Logs");
    backButton.setStyle("-fx-background-color: #2ecc71; -fx-text-fill: white; -fx-padding: 10 25; -fx-background-radius: 8; -fx-font-size: 14px;");
    backButton.setOnAction(e -> {
        VBox logsView = createActivityLogsView(primaryStage, rightContent);
        rightContent.getChildren().clear();
        rightContent.getChildren().add(logsView);
    });

    HBox backButtonBox = new HBox(backButton);
    backButtonBox.setAlignment(Pos.CENTER_LEFT);
    backButtonBox.setStyle("-fx-padding: 20 0;");

    profileLayout.getChildren().addAll(profileHeader, prescriptionButton, labReportButton, backButtonBox);
    scrollPane.setContent(profileLayout);
    rightContent.getChildren().clear();
    rightContent.getChildren().add(scrollPane);
}


    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}