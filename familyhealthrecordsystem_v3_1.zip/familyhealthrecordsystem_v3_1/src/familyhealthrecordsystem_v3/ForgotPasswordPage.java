package familyhealthrecordsystem_v3;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ForgotPasswordPage {

    private final Stage primaryStage;
    private final LoginPage loginPage;

    public ForgotPasswordPage(Stage primaryStage, LoginPage loginPage) {
        this.primaryStage = primaryStage;
        this.loginPage = loginPage;
    }

    public Scene getForgotPasswordScene() {
        VBox layout = new VBox(12);
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-padding: 30; -fx-background-color: #f0f8ff; -fx-border-radius: 10; -fx-background-radius: 10;");

        Label title = new Label("Security Verification");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

        Label q1 = new Label("What is your hobby?");
        TextField answer1 = new TextField();
        answer1.setPromptText("e.g. Painting");
        answer1.setPrefWidth(300); // ✅ Reduced width
        answer1.setStyle("-fx-border-radius: 5px; -fx-background-radius: 5px; -fx-padding: 8;");

        Label message = new Label();
        message.setStyle("-fx-text-fill: red;");

        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("Enter new password");
        newPasswordField.setVisible(false);
        newPasswordField.setPrefWidth(300); // ✅ Reduced width
        newPasswordField.setStyle("-fx-border-radius: 5px; -fx-background-radius: 5px; -fx-padding: 8;");

        Button resetButton = new Button("Reset Password");
        resetButton.setStyle("-fx-background-color: #28a745; -fx-text-fill: white; -fx-border-radius: 5px; -fx-padding: 8 16;");
        resetButton.setVisible(false);

        Button verifyBtn = new Button("Verify");
        verifyBtn.setStyle("-fx-background-color: #1e90ff; -fx-text-fill: white; -fx-border-radius: 5px; -fx-padding: 8 16;");

        verifyBtn.setOnAction(e -> {
            String enteredAnswer = answer1.getText().trim().toLowerCase();
            String actualAnswer = loginPage.getSecurityAnswer().trim().toLowerCase();

            if (!actualAnswer.isEmpty() && enteredAnswer.equals(actualAnswer)) {
                message.setText("Verified! You may now reset your password.");
                message.setStyle("-fx-text-fill: green;");
                newPasswordField.setVisible(true);
                resetButton.setVisible(true);
            } else {
                message.setText("Incorrect answer. Try again.");
                message.setStyle("-fx-text-fill: red;");
                newPasswordField.setVisible(false);
                resetButton.setVisible(false);
            }
        });

        resetButton.setOnAction(e -> {
            String newPass = newPasswordField.getText().trim();
            if (newPass.length() < 4) {
                message.setText("❌ Password must be at least 4 characters.");
                message.setStyle("-fx-text-fill: red;");
            } else {
                loginPage.setSignUpCredentials(loginPage.getSignUpUsername(), newPass);
                message.setText("✅ Password reset successfully!");
                message.setStyle("-fx-text-fill: green;");
            }
        });

        Button backBtn = new Button("Back to Login");
        backBtn.setStyle("-fx-background-color: transparent; -fx-border-color: #1e90ff; -fx-text-fill: #1e90ff; -fx-border-radius: 5px; -fx-padding: 8 16;");
        backBtn.setOnAction(e -> {
            primaryStage.setScene(loginPage.getLoginPage());
        });

        layout.getChildren().addAll(
                title,
                q1, answer1,
                verifyBtn,
                newPasswordField,
                resetButton,
                message,
                backBtn
        );

        return new Scene(layout, 450, 400);
    }
}
