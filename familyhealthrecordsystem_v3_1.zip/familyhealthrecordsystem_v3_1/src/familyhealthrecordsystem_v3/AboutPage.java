package familyhealthrecordsystem_v3;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class AboutPage {

    // Method to create the About section (Team Info)
    public VBox getAboutSection() {
        VBox aboutSection = new VBox(20);
        aboutSection.setAlignment(Pos.CENTER);
        aboutSection.setStyle("-fx-padding: 20;");

        // About Team Info
        Label aboutLabel = new Label("About Us");
        aboutLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #1e90ff;");

        Label teamNameLabel = new Label("Team Name:Team B6");
        teamNameLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #333333;");

        Label teamMembersLabel = new Label("We are a team of three members working on this project:");
        teamMembersLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #333333;");

        Label member1 = new Label(" Member 1: MD. ARIF SHAHRIAR");
        member1.setStyle("-fx-font-size: 14px; -fx-text-fill: #333333;");
        
        Label member2 = new Label(" Member 2: MUARIF HASNAT");
        member2.setStyle("-fx-font-size: 14px; -fx-text-fill: #333333;");
        
        Label member3 = new Label(" Member 3: ASHIKUR RAHMAN ALIF");
        member3.setStyle("-fx-font-size: 14px; -fx-text-fill: #333333;");

        // Adding all labels to the About section
        aboutSection.getChildren().addAll(
                aboutLabel, teamNameLabel, teamMembersLabel, member1, member2, member3
        );

        return aboutSection;
    }
}
