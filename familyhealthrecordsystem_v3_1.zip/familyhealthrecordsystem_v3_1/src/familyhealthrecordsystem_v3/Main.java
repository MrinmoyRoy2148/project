package familyhealthrecordsystem_v3;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create an instance of the LoginPage class
        LoginPage loginPage = new LoginPage(primaryStage);

        // Get the login scene from the LoginPage class and set it as the initial scene
        Scene loginScene = loginPage.getLoginPage();

        // Set the title of the main window (Login Page)
        primaryStage.setTitle("Family Health Record Management System");

        // Set the scene to the login page
        primaryStage.setScene(loginScene);

        // Fix window size
        primaryStage.setWidth(800);
        primaryStage.setHeight(600);
        primaryStage.setResizable(false);

        // Show the window
        primaryStage.show();
    }

    public static void main(String[] args) {
        // Launch the application
        launch(args);
    }
}
