package familyhealthrecordsystem_v3;

import javafx.animation.*;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

public class SignUpPage {

    private final Stage primaryStage;
    private final LoginPage loginPage;

    public SignUpPage(Stage primaryStage, LoginPage loginPage) {
        this.primaryStage = primaryStage;
        this.loginPage = loginPage;
    }

    public Scene getSignUpPage() {
        VBox signUpVBox = new VBox(20);
        signUpVBox.setAlignment(Pos.CENTER);
        signUpVBox.setSpacing(10);
        signUpVBox.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-padding: 40;" +
            "-fx-border-radius: 10px;"
        );

        ImageView profileImage = new ImageView();
        try {
            profileImage.setImage(new Image("file:/F:/BAUST_2_1/CSE%202100_Software%20Development%20Project%20I/Final_project_image/images%20(1).png"));
        } catch (Exception e) {
            System.out.println("Error loading image: " + e.getMessage());
        }
        profileImage.setFitWidth(80);
        profileImage.setFitHeight(80);

        Label signUpLabel = new Label("Create a New Account");
        signUpLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: white;");

        TextField signUpUsernameField = new TextField();
        signUpUsernameField.setPromptText("Username");
        signUpUsernameField.setStyle("-fx-font-size: 14px; -fx-padding: 10; -fx-border-color: #1e90ff; -fx-border-radius: 15px; -fx-background-radius: 15px;");
        signUpUsernameField.setPrefWidth(350);

        PasswordField signUpPasswordField = new PasswordField();
        signUpPasswordField.setPromptText("Password");
        signUpPasswordField.setStyle("-fx-font-size: 14px; -fx-padding: 10; -fx-border-color: #1e90ff; -fx-border-radius: 15px; -fx-background-radius: 15px;");
        signUpPasswordField.setPrefWidth(350);

        PasswordField signUpConfirmPasswordField = new PasswordField();
        signUpConfirmPasswordField.setPromptText("Confirm Password");
        signUpConfirmPasswordField.setStyle("-fx-font-size: 14px; -fx-padding: 10; -fx-border-color: #1e90ff; -fx-border-radius: 15px; -fx-background-radius: 15px;");
        signUpConfirmPasswordField.setPrefWidth(350);

        Label securityQuestionLabel = new Label("What is your favorite hobby?");
        securityQuestionLabel.setStyle("-fx-text-fill: white;");

        TextField securityAnswerField = new TextField();
        securityAnswerField.setPromptText("e.g. painting, reading");
        securityAnswerField.setStyle("-fx-font-size: 14px; -fx-padding: 10; -fx-border-color: #1e90ff; -fx-border-radius: 15px; -fx-background-radius: 15px;");
        securityAnswerField.setPrefWidth(350);

        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red;");

        Button submitButton = new Button("Submit");
        submitButton.setStyle("-fx-font-size: 14px; -fx-padding: 10; -fx-background-color: #1e90ff; -fx-text-fill: white; -fx-border-radius: 5px;");

        signUpVBox.getChildren().addAll(
            profileImage,
            signUpLabel,
            signUpUsernameField,
            signUpPasswordField,
            signUpConfirmPasswordField,
            securityQuestionLabel,
            securityAnswerField,
            errorLabel,
            submitButton
        );

        Label motivationalText = new Label("Life is happy when you are healthy");
        motivationalText.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");
        motivationalText.setFont(new Font("Arial", 30));
        motivationalText.setWrapText(true);
        motivationalText.setMaxWidth(200);
        motivationalText.setPadding(new Insets(20));

        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(2), motivationalText);
        fadeTransition.setFromValue(0.2);
        fadeTransition.setToValue(1.0);
        fadeTransition.setCycleCount(Animation.INDEFINITE);
        fadeTransition.setAutoReverse(true);

        TranslateTransition translateTransition = new TranslateTransition(Duration.seconds(3), motivationalText);
        translateTransition.setByX(15);
        translateTransition.setCycleCount(Animation.INDEFINITE);
        translateTransition.setAutoReverse(true);

        ParallelTransition animation = new ParallelTransition(fadeTransition, translateTransition);
        animation.play();

        HBox mainLayout = new HBox(30);
        mainLayout.setAlignment(Pos.CENTER);
        mainLayout.setStyle("-fx-background-color: linear-gradient(to bottom, #6a5acd, #836fff, #b0c4de);");
        mainLayout.setPadding(new Insets(40));
        mainLayout.getChildren().addAll(motivationalText, signUpVBox);

        mainLayout.prefWidthProperty().bind(primaryStage.widthProperty());
        mainLayout.prefHeightProperty().bind(primaryStage.heightProperty());

        FadeTransition fadeIn = new FadeTransition(Duration.seconds(0.8), mainLayout);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);
        fadeIn.play();

        TranslateTransition slideIn = new TranslateTransition(Duration.seconds(0.5), mainLayout);
        slideIn.setFromX(primaryStage.getWidth());
        slideIn.setToX(0);
        slideIn.play();

        submitButton.setOnMouseEntered(e -> scaleButton(submitButton, 1.1));
        submitButton.setOnMouseExited(e -> scaleButton(submitButton, 1.0));

        submitButton.setOnAction(e -> {
            String username = signUpUsernameField.getText();
            String password = signUpPasswordField.getText();
            String confirmPassword = signUpConfirmPasswordField.getText();
            String securityAnswer = securityAnswerField.getText().trim().toLowerCase();

            if (password.equals(confirmPassword)) {
                loginPage.setSignUpCredentials(username, password);
                loginPage.setSecurityAnswer(securityAnswer);
                Scene loginScene = loginPage.getLoginPage();
                primaryStage.setScene(loginScene);
            } else {
                errorLabel.setText("Passwords do not match!");
            }
        });

        return new Scene(mainLayout, 700, 400, Color.web("#6a5acd"));
    }

    private void scaleButton(Button button, double scale) {
        ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
        st.setToX(scale);
        st.setToY(scale);
        st.play();
    }
}
